{{-- Empty email template to prevent default Laravel emails --}}
